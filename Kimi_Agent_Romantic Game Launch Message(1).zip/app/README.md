# 400 — Our Little Universe

Game hadiah 3D dari Sofiyan untuk Via, dibuat untuk merayakan api ke-400.

## Tujuan

Jelajahi empat babak taman bintang, uraikan Ragu dengan tembakan cahaya, kumpulkan 400 serpihan kenangan, dan jaga Cahayamu serta Api Kita. Setiap babak membuka pesan personal; babak terakhir berisi pertarungan bos dan surat untuk Via.

## Kontrol

- **WASD / tombol panah** — bergerak
- **Klik tahan / J** — menembakkan cahaya; tanpa arah mouse, serangan membidik Ragu terdekat
- **Space** — dash dengan kekebalan singkat
- **E** — Pulse Rindu saat energi penuh; memulihkan, merusak Ragu di sekitar, dan membersihkan proyektil
- **Esc / P** — jeda atau lanjut
- **Perangkat sentuh** — joystick kiri, tombol Cahaya, Dash, dan Rindu di kanan

## Menjalankan

```bash
npm install
npm run dev
```

Build produksi:

```bash
npm run build
npm run preview
```

## Deploy ke Vercel

Impor folder proyek sebagai proyek Vite. Build command: `npm run build`; output directory: `dist`. Tidak ada backend atau variabel lingkungan yang dibutuhkan. Musik tersedia lokal di `public/music/our-song.mp3`.

## Sistem utama

- Empat babak dengan komposisi musuh dan pesan berbeda
- Tiga jenis Ragu dengan perilaku berbeda dan bos dua fase
- Tembakan otomatis membidik, dash, pulse, kombo, magnet kenangan, dua sumber daya yang harus dijaga
- Skor terbaik, preferensi musik, dan kualitas tersimpan lokal di browser perangkat ini
- Kualitas HD/ECO dan degradasi otomatis saat frame rate rendah

## Teknik

React untuk shell/HUD, Three.js untuk dunia dan gameplay, geometri prosedural, instancing, pooled entities, shader langit/air/kelopak, bloom, fixed-timestep 60 Hz, serta Web Audio untuk efek suara.
